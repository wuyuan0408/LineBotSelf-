# かずみの單機半垢
A linebot built by my friend.

安裝termux  
打開輸入  
pkg update -y  
pkg upgrade -y  
pkg install python3 -y  
pkg install git -y  
pip3 install rsa  
pip3 install thrift==0.11.0  
pip3 install requests  
pip3 install pytz  
pip3 install humanfriendly  
git clone https://github.com/tmdChen/KazumiLineBot  
cd botline kazumi  
python3 x.py  
